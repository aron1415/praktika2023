from django.db import models

    
class PriceListElem(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100, default='Услуга', verbose_name='Услуга')
    price = models.IntegerField(default=0, verbose_name='Цена')
    description = models.TextField(default='Описание', verbose_name='Описание')

    def __str__(self) -> str:
        return self.title
    

class Employee(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100, default='ФИО', verbose_name='ФИО')
    description = models.TextField(default='Описание', verbose_name='Описание')
    img = models.ImageField(upload_to='media/', verbose_name='Фото')

    def __str__(self) -> str:
        return self.name
    
class News(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100, default='Название', verbose_name='Название')
    description = models.TextField(default='Описание', verbose_name='Описание')
    date = models.DateField(default='2023-01-01', verbose_name='Дата')

    def __str__(self) -> str:
        return self.title

