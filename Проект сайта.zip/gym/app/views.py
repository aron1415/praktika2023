from django.shortcuts import render
from django.urls import reverse_lazy
from .models import PriceListElem, Employee, News
from django.views.generic import CreateView


def render_index(request):
    price_list = PriceListElem.objects.all()
    return render(request, 'index.html', {
        'price_list': price_list,
})

def render_employees(request):
    employees = Employee.objects.all()
    return render(request, 'employees.html', {
        'employees': employees,
})

def render_news(request):
    news = News.objects.all()
    return render(request, 'news.html', {
        'news': news,
})

def render_about(request):
    return render(request, 'about.html', {
})