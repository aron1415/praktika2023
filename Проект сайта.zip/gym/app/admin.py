from django.contrib import admin
from . import models

@admin.register(models.PriceListElem)
class PriceListElemAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'price', 'description')


@admin.register(models.Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'description')

@admin.register(models.News)
class NewsAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'description', 'date')
