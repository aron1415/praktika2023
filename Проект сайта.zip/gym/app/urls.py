from django.urls import path
from . import views

app_name = 'app'
urlpatterns = [
    path('', views.render_index, name='index'),
    path('employees/', views.render_employees, name='employee'),
    path('news/', views.render_news, name='news'),
    path('about/', views.render_about, name='about'),
]